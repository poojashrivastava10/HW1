package src.ds;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Node {

    private final Map<String, Node> nextnode;
    private int counter;

    public Node() {
    	nextnode = new HashMap<>();
        counter = 0;
    }

    public void increase() {
    	counter ++;
    }

    public void insert(String label) {
    	nextnode.putIfAbsent(label, new Node());
    	nextnode.get(label).increase();
    }

    public Node get(String label) {
        return nextnode.getOrDefault(label, new Node());
    }

    public double probability(String label) {
        if (!nextnode.containsKey(label)) {
            return 0D;
        }
        int count = get(label).count();
        int total = nextnode.values().stream().mapToInt(Node::count).sum();
        return ((double) count) / ((double) total);
    }

    public Set<String> possibilities() {
        return nextnode.keySet();
    }

    public int count() {
        return counter;
    }

}
