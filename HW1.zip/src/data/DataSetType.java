package src.data;

public enum DataSetType {

    POSITIVE, NEGATIVE, AGGREGATE;

}


