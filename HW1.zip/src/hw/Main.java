package src.hw;


	import src.AnyGram.AnyGram;
import src.AnyGram.AnyGramCalculater;
import src.data.DataSetType;
	import src.data.Database;
import src.ds.Node;
import src.io.InputDataSet;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
	import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
	import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;

	public class Main {

	    public static void main(String[] args) throws Exception {
	    	final File folder = new File("C:/Users/Nachiketa/Desktop/HW1/data"); 
			ArrayList<String> Lines= readfiles("C:/Users/Nachiketa/Desktop/HW1/ALL");

	        final Database database = new Database();
	        final int limit = 3;
	        final InputDataSet reader = new InputDataSet(limit);

	        reader.read(database, DataSetType.NEGATIVE, new File(folder, "Neg"));
	        reader.read(database, DataSetType.POSITIVE, new File(folder, "Pos"));

	        // Question #1
			noofwords(Lines);
			
	        // Question #2
			noofuniquewords(Lines);
			
	        // Question #3
	        TopTenNGrams(database);
	        
	        // Question #5
	        SampleProbabilities(database);
	    }

	    private static void SampleProbabilities(final Database dataset) {
	        System.out.println("Sample Tri-gram probabilities:");
	        final Node root = dataset.dataSet(DataSetType.AGGREGATE).root();
	        System.out.println(" 1) P{guard | the, coast} = " + root.get("the").get("coast").probability("guard"));
	        System.out.println(" 2) P{of | a, couple} = " + root.get("a").get("couple").probability("of"));
	        System.out.println(" 3) P{is | this, movie} = " + root.get("this").get("movie").probability("is"));
	        System.out.println(" 4) P{of | a, lot} = " + root.get("a").get("lot").probability("of"));
	        System.out.println(" 5) P{the | singin, in} = " + root.get("singin").get("in").probability("the"));
	    }

	    private static void TopTenNGrams(final Database dataset) {
	        System.out.println();
	        final AnyGramCalculater Agcal = new AnyGramCalculater();

	        for (DataSetType type : DataSetType.values()) {
	            for (int i = 2; i <= 3; i++) {
	                System.out.println("Top 10 " + i + "-grams for data set " + type + ":");
	                final Node root = dataset.dataSet(type).root();
	                final Map<AnyGram, Double> map = Agcal.find(root, i);
	                final List<AnyGram> aGrams = new ArrayList<>(map.keySet());
	                aGrams.sort(Comparator.comparingDouble(map::get).reversed());
	                for (int j = 0; j < Math.min(10, aGrams.size()); j++) {
	                    final AnyGram aGram = aGrams.get(j);
	                    System.out.println((j + 1) + ") " + aGram + "- Probablity = " + map.get(aGram) + " , "
	                                               + "Frequency = " + aGram.frequency(root));
	                }
	            }
	        }
	    }
	    
	    public static ArrayList<String> readfiles (String path) throws FileNotFoundException
	    {
	    	File dir = new File(path);
	    	ArrayList<String> lines = new ArrayList<String>();
	    	
	    	for (File files : dir.listFiles()) 
	    	{	    		
	    	    Scanner s = new Scanner(files);	
	    	    ArrayList<String> line = new ArrayList<String>();

	    		while (s.hasNextLine())
	    		{
	    			line.add(s.nextLine());
	    		}
	    				
	    		lines.addAll(line);
	    		s.close();	    		
	    	}	    	
	    	return lines;	    	
	    }

	    public static void noofwords(ArrayList<String> Lines)
	    {
	    	int words = 0;
	    	for (String s : Lines)
	    	{	    		
	    		words=words+s.split(" ").length;
	    	}
	    	System.out.println("The total number of words in the reviews are: "+words);
	    }

	    public static void noofuniquewords(ArrayList<String> Lines)
	    {
	        String word;
	        HashMap<String , Integer> Hmap = new HashMap<>();
	        
	        for (String S : Lines) 
	        {
	        	StringTokenizer st = new StringTokenizer(S);
	        	while (st.hasMoreTokens())
	        	{
	        		word = st.nextToken();
	        		int val =0;
	               		        		
	        		if (Hmap.containsKey(word))
	        		{
	        			val = Hmap.get(word).intValue();
	        			val = val +1;
	        			Hmap.put(word, val);
	        		}
	        		else
	        		{
	        			Hmap.put(word, 1);
	        		}
	        	}
	         }
	        int count =0;
	        for(int i : Hmap.values())
	        {
	            if (i==1)
	                count++;
	        }
	        System.out.println("The total no of Unique words:" +count);
	    }

	}
	

