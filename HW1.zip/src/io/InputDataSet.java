package src.io;

import src.data.DataSetType;
import src.data.Database;

import java.io.File;
import java.io.IOException;

public class InputDataSet {

    private final InputFile fr;

    public InputDataSet(final int limit) {
        fr = new InputFile(limit);
    }

    public void read(Database db, DataSetType type, File folder) throws IOException {

        final File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
            	fr.read(db, file, type, DataSetType.AGGREGATE);

            }
        }
 
    }

}
